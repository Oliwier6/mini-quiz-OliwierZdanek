package pl.zst.oliwier.quiz;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.app.AlertDialog;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.activity.EdgeToEdge;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    TextView Pytanka, Wynik;
    Button startButton, resetButton, OdpA, OdpB, OdpC;

    ArrayList<Pytania> quiz;
    int index = 0;
    int score = 0;

    Pytania[] WszytskiePytania = {
            new Pytania("Imie i nazwisko Egzorcysty:", "Bogdan Boner", "Bartosz Walaszek", "poprostu Domino", "Bogdan Boner"),
            new Pytania("Ile zarabiał Domino", "nie całe 300", "moze i nie duzo, za to wcale", "dopłacał", "moze i nie duzo, za to wcale"),
            new Pytania("Najwiekszy członek Blok ekipy:", "Cieślak", "Walu", "Spejson", "Spejson"),
            new Pytania("Czym ziomeczki wozili sie po odcinku 131", "bawarą", "szerszeniem", "golfem", "Delfin"),
            new Pytania("Stolica Polski to:", "Kraków", "Warszawa", "Gdańsk", "Warszawa")
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        startButton = findViewById(R.id.startButton);
        resetButton = findViewById(R.id.resetButton);
        Pytanka = findViewById(R.id.questionText);
        Wynik = findViewById(R.id.Wynik);
        OdpA= findViewById(R.id.answerA);
        OdpB = findViewById(R.id.answerB);
        OdpC = findViewById(R.id.answerC);

        // Nasłuchiwanie kliknięć
        startButton.setOnClickListener(v -> startQuiz());

        OdpA.setOnClickListener(v -> check(OdpA.getText().toString()));
        OdpB.setOnClickListener(v -> check(OdpB.getText().toString()));
        OdpC.setOnClickListener(v -> check(OdpC.getText().toString()));

        resetButton.setOnClickListener(v -> resetQuiz());

        resetQuiz();
    }

    private void startQuiz() {
        quiz = new ArrayList<>();
        Collections.addAll(quiz, WszytskiePytania);
        Collections.shuffle(quiz);
        quiz = new ArrayList<>(quiz.subList(0, 5));

        index = 0;
        score = 0;
        Wynik.setText("Wynik: 0");

        startButton.setVisibility(View.GONE);

        showQuestion();
    }

    private void showQuestion() {
        if (index >= quiz.size()) {
            new AlertDialog.Builder(this)
                    .setTitle("Koniec quizu!")
                    .setMessage("Twój wynik: " + score + " / 5")
                    .setPositiveButton("OK", null)
                    .show();
            startButton.setVisibility(View.VISIBLE);
            return;
        }

        Pytania q = quiz.get(index);

        Pytanka.setVisibility(View.VISIBLE);
        OdpA.setVisibility(View.VISIBLE);
        OdpB.setVisibility(View.VISIBLE);
        OdpC.setVisibility(View.VISIBLE);

        Pytanka.setText(q.text);
        OdpA.setText(q.a);
        OdpB.setText(q.b);
        OdpC.setText(q.c);
    }

    private void check(String answer) {
        if (answer.equals(quiz.get(index).correct)) {
            score++;
            Wynik.setText("Wynik: " + score);
        }

        index++;
        showQuestion();
    }

    private void resetQuiz() {
        score = 0;
        Wynik.setText("Wynik: 0");

        Pytanka.setVisibility(View.GONE);
        OdpA.setVisibility(View.GONE);
        OdpB.setVisibility(View.GONE);
        OdpC.setVisibility(View.GONE);

        startButton.setVisibility(View.VISIBLE);
    }
}