package pl.zst.oliwier.quiz;

public class Pytania{
    public String text;
    public String a, b, c;
    public String correct;

    public Pytania(String text, String a, String b, String c, String correct) {
        this.text = text;
        this.a = a;
        this.b = b;
        this.c = c;
        this.correct = correct;
    }
}